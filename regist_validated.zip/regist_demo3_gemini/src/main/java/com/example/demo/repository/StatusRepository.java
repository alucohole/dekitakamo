package com.example.demo.repository;

import com.example.demo.entity.Status;

public interface StatusRepository {
    Status findById(Integer statusId);
}