package com.example.demo.controller;

import jakarta.servlet.http.HttpSession; // HttpSession を使用

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.demo.entity.Attendance;
import com.example.demo.exception.BusinessException;
import com.example.demo.form.AttendanceForm;
import com.example.demo.service.AttendanceService;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
public class AttendanceController {
	
	private final AttendanceService service;

	// GETリクエストで勤怠登録フォームを表示
	@GetMapping("/stamp_regist")
	public String showRegistFormGet(@RequestParam(required = false) String id, Model model, HttpSession session) {
	    AttendanceForm form = new AttendanceForm();
	    String employeeIdFromSession = (String) session.getAttribute("loggedInEmployeeId");

	    if (id != null) { // URLパラメータにIDがあればそれを使う
	        form.setEmployeeId(id);
	    } else if (employeeIdFromSession != null) { // なければセッションのIDを使う
            form.setEmployeeId(employeeIdFromSession);
        }
        // ここで form.employeeId がセットされていることを確認（必須）
        
	    model.addAttribute("attendanceForm", form);
        model.addAttribute("employeeId", session.getAttribute("loggedInEmployeeId")); // セッションからID
        model.addAttribute("employeeName", session.getAttribute("loggedInEmployeeName")); // セッションから名前
	    return "stamp_regist";
	}

    // POSTリクエストで勤怠登録フォームを表示するメソッド
    @PostMapping("/stamp_regist")
    public String showRegistFormPost(@RequestParam(required = false) String id, Model model, HttpSession session) {
        AttendanceForm form = new AttendanceForm();
        String employeeIdFromSession = (String) session.getAttribute("loggedInEmployeeId");

        if (id != null) { // URLパラメータにIDがあればそれを使う
            form.setEmployeeId(id);
        } else if (employeeIdFromSession != null) { // なければセッションのIDを使う
            form.setEmployeeId(employeeIdFromSession);
        }
        // ここで form.employeeId がセットされていることを確認（必須）

        model.addAttribute("attendanceForm", form);
        model.addAttribute("employeeId", session.getAttribute("loggedInEmployeeId")); // セッションからID
        model.addAttribute("employeeName", session.getAttribute("loggedInEmployeeName")); // セッションから名前
        return "stamp_regist";
    }

	@PostMapping("/confirm_regist")
	public String submitAttendance(@Validated @ModelAttribute AttendanceForm form,
			Model model,
			BindingResult result,
			RedirectAttributes redirectAttributes) {
		
		System.out.println(model);
		
		if (result.hasErrors()) {
			model.addAttribute("attendanceForm", form);
			if (form.getStatusId() != null) {
			    String statusName = service.getStatusNameById(form.getStatusId()); 
			    model.addAttribute("statusName", statusName);
			}
			return "stamp_regist";
		}

		String statusName = service.getStatusNameById(form.getStatusId());
		model.addAttribute("statusName", statusName);

		return "confirm_regist";
	}

	@PostMapping("/complete")
	public String registAttendance(@Validated @ModelAttribute AttendanceForm form,
			Model model,
			BindingResult result,
			RedirectAttributes redirectAttributes) {
		
		if (result.hasErrors()) {
			redirectAttributes.addFlashAttribute("errorMessage", "フォームの入力内容にエラーがあります。");
			redirectAttributes.addFlashAttribute("attendanceForm", form);
			return "redirect:/stamp_regist"; 
		}

		try {
			Attendance at = new Attendance();
			at.setEmployeeId(form.getEmployeeId());
			at.setStatusId(form.getStatusId());
			at.setWorkDate(form.getWorkDate());
			at.setStartTime(form.getStartTime());
			at.setEndTime(form.getEndTime());
			at.setBreakTime(form.getBreakTime());
			at.setComments(form.getComments());
			service.regist(at);
			
			redirectAttributes.addFlashAttribute("msg", "勤怠登録");

		} catch (BusinessException e) {
			redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
			redirectAttributes.addFlashAttribute("attendanceForm", form);
			return "redirect:/stamp_regist"; 
		} catch (Exception e) {
		    redirectAttributes.addFlashAttribute("errorMessage", "予期せぬエラーが発生しました: " + e.getMessage());
		    redirectAttributes.addFlashAttribute("attendanceForm", form);
		    return "redirect:/stamp_regist";
		}

		return "redirect:/complete";
	}
	
	@GetMapping("/complete")
	public String showComplete(Model model) {
	    return "complete";
	}

	@GetMapping("/top")
	public String returnTopGet(Model model) {
		return "top";
	}

	@PostMapping("/top_from_register")
	public String returnTopPost(@RequestParam(required = false) String id,
			Model model,
			@ModelAttribute AttendanceForm form) {
		return "redirect:/top";
	}
}