package com.example.demo.repository;

import java.sql.Date;
import java.time.LocalTime;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Attendance;

import lombok.RequiredArgsConstructor;

@Repository
@RequiredArgsConstructor
public class AttendanceRepositoryImpl implements AttendanceRepository {

    private final JdbcTemplate jdbcTemplate;

    @Override
    public void add(Attendance attendance) {

        String sql = " INSERT INTO attendance_info " +
                " (employee_id, status_id, work_date, start_time, end_time, break_time, comments) " +
                " VALUES (?, ?, ?, ?, ?, ?, ?) ";

        jdbcTemplate.update(sql,
                attendance.getEmployeeId(),
                attendance.getStatusId(),
                Date.valueOf(attendance.getWorkDate()), // ★LocalDateからjava.sql.Dateへの変換★
                attendance.getStartTime(),
                attendance.getEndTime(),
                attendance.getBreakTime(),
                attendance.getComments());
    }

    @Override
    public List<Attendance> findByEmployeeIdAndWorkDate(String employeeId, Date workDate) {
        String sql = "SELECT REGIST_ID, EMPLOYEE_ID, STATUS_ID, WORK_DATE, START_TIME, END_TIME, BREAK_TIME, COMMENTS " +
                     "FROM ATTENDANCE_INFO WHERE EMPLOYEE_ID = ? AND WORK_DATE = ?";
        return jdbcTemplate.query(sql, (rs, rowNum) -> {
            Attendance attendance = new Attendance();
            attendance.setRegistId(rs.getInt("REGIST_ID"));
            attendance.setEmployeeId(rs.getString("EMPLOYEE_ID"));
            attendance.setStatusId(rs.getInt("STATUS_ID"));
            attendance.setWorkDate(rs.getDate("WORK_DATE").toLocalDate()); // ★java.sql.DateからLocalDateへの変換★
            attendance.setStartTime(rs.getObject("START_TIME", LocalTime.class));
            attendance.setEndTime(rs.getObject("END_TIME", LocalTime.class));
            attendance.setBreakTime(rs.getInt("BREAK_TIME"));
            attendance.setComments(rs.getString("COMMENTS"));
            return attendance;
        }, employeeId, workDate);
    }
}