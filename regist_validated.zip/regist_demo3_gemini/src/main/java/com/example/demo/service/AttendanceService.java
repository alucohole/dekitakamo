package com.example.demo.service;

import com.example.demo.entity.Attendance;

public interface AttendanceService {
	 void regist(Attendance attendance);
	 String getStatusNameById(Integer statusId);
}