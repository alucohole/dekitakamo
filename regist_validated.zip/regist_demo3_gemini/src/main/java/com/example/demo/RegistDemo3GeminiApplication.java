package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegistDemo3GeminiApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegistDemo3GeminiApplication.class, args);
	}

}
