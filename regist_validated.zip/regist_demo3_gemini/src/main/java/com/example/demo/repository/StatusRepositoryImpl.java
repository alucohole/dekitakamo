package com.example.demo.repository;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Status;

import lombok.RequiredArgsConstructor;

@Repository
@RequiredArgsConstructor
public class StatusRepositoryImpl implements StatusRepository {

    private final JdbcTemplate jdbcTemplate;

    @Override
    public Status findById(Integer statusId) {
        String sql = "SELECT STATUS_ID, STATUS_NAME FROM STATUS WHERE STATUS_ID = ?";
        try {
            return jdbcTemplate.queryForObject(sql, (rs, rowNum) -> {
                Status status = new Status();
                status.setStatusId(rs.getInt("STATUS_ID"));
                status.setStatusName(rs.getString("STATUS_NAME"));
                return status;
            }, statusId);
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }
}