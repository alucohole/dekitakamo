package com.example.demo.controller;

import jakarta.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.constant.ErrorMessage; // ErrorMessage も使用する
import com.example.demo.entity.Account; // ★これをimport★
import com.example.demo.entity.Login; // Loginエンティティも残しておく
import com.example.demo.entity.LoginResult; // LoginResultは使わないので不要になる（あるいは変更）
import com.example.demo.form.LoginForm;
import com.example.demo.service.LoginService;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
public class LoginController {

    private final LoginService loginService;

    @GetMapping({ "/login","/" }) // URLパスは以前の提案に戻します
    public String showLoginTop(Model model) {
        model.addAttribute("loginForm", new LoginForm());
        return "login";
    }

    @PostMapping("/top") // トップページへのPOSTは維持
    public String checkLogin(
            @RequestParam String id,
            @RequestParam String pass,
            Model model,
            HttpSession session) { // AttendanceFormはここで使わないので削除

        // LoginForm を手動で作成し、@RequestParam で受け取った値を設定
        LoginForm loginForm = new LoginForm();
        loginForm.setEmployeeId(id);
        loginForm.setPassword(pass);

        // Loginエンティティに変換
        Login login = new Login(id, pass); 

        // サービス層の呼び出しとセッションへの保存
        LoginResult lr = loginService.checkLogin(login); // LoginResultは維持し、内部でAccountを持つように変更する

        if (lr.isActive()) {
            // LoginResultからAccount情報を取得してセッションに保存
            Account loggedInAccount = lr.getAccount(); // LoginResultにgetAccount()メソッドを追加

            session.setAttribute("loggedInEmployeeId", loggedInAccount.getEmployeeId());
            session.setAttribute("loggedInEmployeeName", loggedInAccount.getName());
            session.setAttribute("loggedInAuthority", loggedInAccount.getAuthority()); // 権限もセッションに保存しておくと便利

            model.addAttribute("authority", loggedInAccount.getAuthority());
            model.addAttribute("id", loggedInAccount.getEmployeeId()); // top.htmlに渡すidはAccountから
            return "top";
        } else {
            model.addAttribute("errorMessage", ErrorMessage.LOGIN_FAILURE);
            model.addAttribute("loginForm", loginForm); // エラー時にフォームの値を保持
            return "login";
        }
    }
}