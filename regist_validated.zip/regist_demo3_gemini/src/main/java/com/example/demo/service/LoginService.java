package com.example.demo.service;

import com.example.demo.entity.Login;
import com.example.demo.entity.LoginResult; // LoginResult を返します

public interface LoginService {
	
	public LoginResult checkLogin(Login login);

    // 以前のauthenticateメソッドはLoginControllerで直接使用しないように変更したため、今回は不要です
    // public EmployeeInfo authenticate(String employeeId, String password); // 必要であれば再追加

}