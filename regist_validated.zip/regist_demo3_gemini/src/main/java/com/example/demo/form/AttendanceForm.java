package com.example.demo.form;

// import java.sql.Date; // これを削除
import java.time.LocalDate; // ★これを追加★
import java.time.LocalTime;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

@Data
public class AttendanceForm {
    private String employeeId;

    @NotNull(message = "日付は必須です")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate workDate; // ★型を LocalDate に変更★

    @NotNull(message = "勤怠区分は必須です")
    private Integer statusId;

    @DateTimeFormat(pattern = "HH:mm")
    private LocalTime startTime;

    @DateTimeFormat(pattern = "HH:mm")
    private LocalTime endTime;

    @NotNull(message = "休憩時間は必須です")
    @PositiveOrZero(message = "休憩時間は0以上の値を入力してください")
    private Integer breakTime;

    private String comments;
}