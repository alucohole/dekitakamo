package com.example.demo.repository;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Dayoff;

import lombok.RequiredArgsConstructor;

@Repository
@RequiredArgsConstructor
public class DayoffRepositoryImpl implements DayoffRepository {

    private final JdbcTemplate jdbcTemplate;

    @Override
    public Dayoff findByEmployeeId(String employeeId) {
        String sql = "SELECT EMPLOYEE_ID, YU_HOLIDAY, FURI_HOLIDAY FROM DAYOFF WHERE EMPLOYEE_ID = ?";
        try {
            return jdbcTemplate.queryForObject(sql, (rs, rowNum) -> {
                Dayoff dayoff = new Dayoff();
                dayoff.setEmployeeId(rs.getString("EMPLOYEE_ID"));
                dayoff.setYuHoliday(rs.getInt("YU_HOLIDAY"));
                dayoff.setFuriHoliday(rs.getInt("FURI_HOLIDAY"));
                return dayoff;
            }, employeeId);
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }

    @Override
    public void updateFuriHoliday(String employeeId, int change) {
        String sql = "UPDATE DAYOFF SET FURI_HOLIDAY = FURI_HOLIDAY + ? WHERE EMPLOYEE_ID = ?";
        jdbcTemplate.update(sql, change, employeeId);
    }

    @Override
    public void updateYuHoliday(String employeeId, int change) {
        String sql = "UPDATE DAYOFF SET YU_HOLIDAY = YU_HOLIDAY + ? WHERE EMPLOYEE_ID = ?";
        jdbcTemplate.update(sql, change, employeeId);
    }

    @Override
    public void insertInitialDayoff(String employeeId) {
        String sql = "INSERT INTO DAYOFF (EMPLOYEE_ID, YU_HOLIDAY, FURI_HOLIDAY) VALUES (?, ?, ?)";
        jdbcTemplate.update(sql, employeeId, 0, 0);
    }
}