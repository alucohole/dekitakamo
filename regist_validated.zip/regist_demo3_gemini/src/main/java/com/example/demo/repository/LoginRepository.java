package com.example.demo.repository;

import com.example.demo.entity.Account;
import com.example.demo.entity.Login; // Login オブジェクトを引数として受け取るため維持

public interface LoginRepository {
    Account findByLogin(Login login); // Login オブジェクトを引数とする形を維持
}