package com.example.demo.repository;

import com.example.demo.entity.Dayoff;

public interface DayoffRepository {
    Dayoff findByEmployeeId(String employeeId);
    void updateFuriHoliday(String employeeId, int change);
    void updateYuHoliday(String employeeId, int change);
    void insertInitialDayoff(String employeeId);
}