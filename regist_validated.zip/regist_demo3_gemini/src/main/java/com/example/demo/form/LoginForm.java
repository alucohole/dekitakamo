package com.example.demo.form;

import lombok.Data;
// バリデーションアノテーションは、@ModelAttribute で直接使用する場合に有効です。
// @RequestParam で受け取る場合は、ここでは直接影響しません。
// import jakarta.validation.constraints.NotBlank;
// import jakarta.validation.constraints.Size;

@Data
public class LoginForm {
    // リクエストパラメータ名 'id' に対応
    private String employeeId; 
    // リクエストパラメータ名 'pass' に対応
    private String password;
}