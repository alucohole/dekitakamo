package com.example.demo.constant;

public class ErrorMessage {
    public static final String DUPLICATE_ATTENDANCE = "指定された日付には既に勤怠が登録されています。";
    public static final String NOT_ENOUGH_FURI_HOLIDAY = "振替休日が不足しています。";
    public static final String NOT_ENOUGH_YU_HOLIDAY = "有給休暇が不足しています。";
    public static final String INVALID_DAY_FOR_ATTENDANCE_STATUS = "この勤怠区分は平日のみ登録可能です。";
    public static final String INVALID_DAY_FOR_DAYOFF_STATUS = "この勤怠区分は休日のみ登録可能です。";
    public static final String LOGIN_FAILURE = "ユーザーIDまたはパスワードが間違っています。";
}