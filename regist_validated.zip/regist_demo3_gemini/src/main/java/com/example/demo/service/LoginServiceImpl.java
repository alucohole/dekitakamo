package com.example.demo.service;

import org.springframework.stereotype.Service;

import com.example.demo.entity.Account; // Account を使用
import com.example.demo.entity.Login;
import com.example.demo.entity.LoginResult; // LoginResult を使用
import com.example.demo.repository.LoginRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class LoginServiceImpl implements LoginService {
	
    private final LoginRepository loginRepository;

	@Override
	public LoginResult checkLogin(Login login) {
		
		LoginResult lr = new LoginResult();
		
		// ログイン認証を行い、Accountオブジェクトを取得
		// LoginRepositoryのfindByLoginメソッドがAccountを返すように実装されている前提
		Account account = loginRepository.findByLogin(login);
		
		if(account != null) {
			lr.setActive(true);
			lr.setAuthority(account.getAuthority());
			lr.setAccount(account); // 取得したAccountオブジェクトをLoginResultにセット
		}
		else {
			lr.setActive(false);
            // ログイン失敗時のエラーメッセージなどを設定する場合はここに追加
            // lr.setErrorMessage(ErrorMessage.LOGIN_FAILURE); // LoginResult に errorMessage フィールドがあれば
		}
		
		return lr;
	}
}