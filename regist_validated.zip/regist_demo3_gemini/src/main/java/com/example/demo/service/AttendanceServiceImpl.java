package com.example.demo.service;

import java.sql.Date; // import java.sql.Date; は不要になりますが、DayoffRepositoryImpl など他の場所で使う可能性があるので残すか確認
import java.time.DayOfWeek;
import java.time.LocalDate; // ★これを追加★
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.constant.ErrorMessage;
import com.example.demo.entity.Attendance;
import com.example.demo.entity.Dayoff;
import com.example.demo.entity.Status;
import com.example.demo.exception.BusinessException;
import com.example.demo.repository.AttendanceRepository;
import com.example.demo.repository.DayoffRepository;
import com.example.demo.repository.StatusRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AttendanceServiceImpl implements AttendanceService {

	private final AttendanceRepository attendanceRepository;
	private final DayoffRepository dayoffRepository;
	private final StatusRepository statusRepository;

	@Override
	@Transactional
	public void regist(Attendance attendance) {
		// 1. 同日勤怠重複登録チェック
		List<Attendance> existingAttendances = attendanceRepository.findByEmployeeIdAndWorkDate(
				attendance.getEmployeeId(), Date.valueOf(attendance.getWorkDate())); // ★LocalDateからjava.sql.Dateへの変換★
		if (!existingAttendances.isEmpty()) {
			throw new BusinessException(ErrorMessage.DUPLICATE_ATTENDANCE);
		}

		// 2. 勤怠区分に応じた平日/休日チェック
		LocalDate workLocalDate = attendance.getWorkDate(); // ★LocalDateを直接使用★
		DayOfWeek dayOfWeek = workLocalDate.getDayOfWeek();
		boolean isWeekday = (dayOfWeek != DayOfWeek.SATURDAY && dayOfWeek != DayOfWeek.SUNDAY);

		switch (attendance.getStatusId()) {
		case 1: // 出勤
		case 3: // 振休
		case 4: // 年休
		case 6: // 欠勤
			if (!isWeekday) {
				throw new BusinessException(ErrorMessage.INVALID_DAY_FOR_ATTENDANCE_STATUS);
			}
			break;
		case 2: // 振出
		case 5: // 休日
			if (isWeekday) {
				throw new BusinessException(ErrorMessage.INVALID_DAY_FOR_DAYOFF_STATUS);
			}
			break;
		}

		// 3. 勤怠区分に応じたDAYOFFテーブルの更新と残数チェック
		Dayoff dayoff = dayoffRepository.findByEmployeeId(attendance.getEmployeeId());
		if (dayoff == null) {
			dayoffRepository.insertInitialDayoff(attendance.getEmployeeId());
			dayoff = dayoffRepository.findByEmployeeId(attendance.getEmployeeId());
		}

		switch (attendance.getStatusId()) {
		case 2: // 振出
			dayoffRepository.updateFuriHoliday(attendance.getEmployeeId(), 1);
			break;
		case 3: // 振休
			if (dayoff.getFuriHoliday() < 1) {
				throw new BusinessException(ErrorMessage.NOT_ENOUGH_FURI_HOLIDAY);
			}
			dayoffRepository.updateFuriHoliday(attendance.getEmployeeId(), -1);
			break;
		case 4: // 年休
			if (dayoff.getYuHoliday() < 1) {
				throw new BusinessException(ErrorMessage.NOT_ENOUGH_YU_HOLIDAY);
			}
			dayoffRepository.updateYuHoliday(attendance.getEmployeeId(), -1);
			break;
		default:
			break;
		}

		// 4. 勤怠情報の登録
		attendanceRepository.add(attendance);
	}

	@Override
	public String getStatusNameById(Integer statusId) {
		Status status = statusRepository.findById(statusId);
		return (status != null) ? status.getStatusName() : "不明";
	}
}