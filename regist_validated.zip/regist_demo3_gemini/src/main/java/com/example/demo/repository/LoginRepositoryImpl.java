package com.example.demo.repository;

import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Account;
import com.example.demo.entity.Login; // Login オブジェクトを引数として受け取るため維持

import lombok.RequiredArgsConstructor;

@Repository
@RequiredArgsConstructor
public class LoginRepositoryImpl implements LoginRepository {

	public final JdbcTemplate jdbcTemplate;

	@Override
	public Account findByLogin(Login login) { // Login オブジェクトを引数とする形を維持
		// EMPLOYEE_ID と PASS を直接クエリで比較
		String sql = "SELECT EMPLOYEE_ID, NAME, DEPARTMENT_ID, PASS, AUTHORITY FROM EMPLOYEE_INFO WHERE EMPLOYEE_ID = ? AND PASS = ?";

		List<Map<String, Object>> list = jdbcTemplate.queryForList(sql, login.getUserId(), login.getPass()); // userId, pass を使用

		if (list.isEmpty()) {
			return null;
		}

		Map<String, Object> one = list.get(0);
		Account account = new Account();
		account.setEmployeeId((String) one.get("EMPLOYEE_ID"));
		account.setName((String)one.get("NAME"));
		account.setDepartmentId((String) one.get("DEPARTMENT_ID"));
		account.setPassword((String) one.get("PASS"));
		account.setAuthority((String) one.get("AUTHORITY"));

		return account;
	}
}