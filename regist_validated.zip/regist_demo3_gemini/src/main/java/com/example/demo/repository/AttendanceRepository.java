package com.example.demo.repository;

import java.sql.Date;
import java.util.List;

import com.example.demo.entity.Attendance;

public interface AttendanceRepository {
	 void add(Attendance attendance);
	 List<Attendance> findByEmployeeIdAndWorkDate(String employeeId, Date workDate);
}