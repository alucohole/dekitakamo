package com.example.demo.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LoginResult {
	
	private String authority;
	private boolean active;
	private Account account; // ★これを追加★ ログイン成功時のAccount情報を保持

}