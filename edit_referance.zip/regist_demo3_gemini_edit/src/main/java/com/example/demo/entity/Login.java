package com.example.demo.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Login {
    private String userId; // リクエスト名に合わせて維持
    private String pass;   // リクエスト名に合わせて維持
}