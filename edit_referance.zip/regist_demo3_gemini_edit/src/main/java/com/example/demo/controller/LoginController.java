package com.example.demo.controller;

import jakarta.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.constant.ErrorMessage;
import com.example.demo.entity.Account; // Account を使用
import com.example.demo.entity.Login;
import com.example.demo.entity.LoginResult;
import com.example.demo.form.LoginForm;
import com.example.demo.service.LoginService;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
public class LoginController {

    private final LoginService loginService;

    @GetMapping({ "/login","/" })
    public String showLoginTop(Model model) {
        model.addAttribute("loginForm", new LoginForm());
        return "login";
    }

    @PostMapping("/top")
    public String checkLogin(
            @RequestParam String id, // String型として受け取る
            @RequestParam String pass,
            Model model,
            HttpSession session) {

        LoginForm loginForm = new LoginForm();
        loginForm.setEmployeeId(id);
        loginForm.setPassword(pass);

        Login login = new Login(id, pass);

        LoginResult lr = loginService.checkLogin(login);

        if (lr.isActive()) {
            Account loggedInAccount = lr.getAccount();

            session.setAttribute("loggedInEmployeeId", loggedInAccount.getEmployeeId()); // ★String型として保存★
            session.setAttribute("loggedInEmployeeName", loggedInAccount.getName());
            session.setAttribute("loggedInAuthority", loggedInAccount.getAuthority());

            model.addAttribute("authority", loggedInAccount.getAuthority());
            model.addAttribute("id", loggedInAccount.getEmployeeId()); // top.htmlに渡すidもString
            return "top";
        } else {
            model.addAttribute("errorMessage", ErrorMessage.LOGIN_FAILURE);
            model.addAttribute("loginForm", loginForm);
            return "login";
        }
    }
}