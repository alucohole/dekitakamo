package com.example.demo.entity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

// @Entity
// @Table(name = "status")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Status {
    // @Id
    // @Column(name = "STATUS_ID")
    private Integer statusId;

    // @Column(name = "STATUS_NAME")
    private String statusName;
}