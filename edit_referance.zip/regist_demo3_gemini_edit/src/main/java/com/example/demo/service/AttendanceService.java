package com.example.demo.service;

import java.time.LocalDate;
import java.util.List;

import com.example.demo.entity.Attendance;
import com.example.demo.entity.Status;
import com.example.demo.exception.BusinessException;

public interface AttendanceService {
    void regist(Attendance attendance) throws BusinessException;
    String getStatusNameById(Integer statusId);
    List<Status> getAllStatuses();
    List<Attendance> searchAttendances(String employeeId, LocalDate startDate, LocalDate endDate);
    void updateAttendance(Attendance updatedAttendance) throws BusinessException;
    Attendance findAttendanceById(Integer registId); // ★この行を追加★
}