package com.example.demo.form;

import java.time.LocalDate;
import java.time.LocalTime;

import jakarta.validation.constraints.NotBlank; // String型バリデーション用
import jakarta.validation.constraints.NotNull; // Integer型バリデーション用

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class AttendanceForm {
    private Integer registId; // 編集時に必要

    @NotBlank(message = "社員IDは必須です。") // String型なのでNotBlank
    private String employeeId; // ★ここをStringに修正★

    @NotNull(message = "日付を入力してください。")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate workDate;

    @NotNull(message = "勤怠区分を選択してください。")
    private Integer statusId;

    @NotNull(message = "開始時間を入力してください。")
    @DateTimeFormat(pattern = "HH:mm")
    private LocalTime startTime;

    @NotNull(message = "終了時間を入力してください。")
    @DateTimeFormat(pattern = "HH:mm")
    private LocalTime endTime;

    @NotNull(message = "休憩時間を入力してください。")
    private Integer breakTime;
    private String comments;
}