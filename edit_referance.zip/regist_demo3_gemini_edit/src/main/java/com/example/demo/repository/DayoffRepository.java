package com.example.demo.repository;

import com.example.demo.entity.Dayoff;

// JpaRepositoryの継承を削除
public interface DayoffRepository {
    Dayoff findByEmployeeId(String employeeId); // ★String型に修正★
    void updateFuriHoliday(String employeeId, int change); // ★String型に修正★
    void updateYuHoliday(String employeeId, int change); // ★String型に修正★
    void insertInitialDayoff(String employeeId); // ★String型に修正★

    // 振休残日数を取得するメソッド
    Integer findFuriHolidayByEmployeeId(String employeeId); // ★String型に修正★
}