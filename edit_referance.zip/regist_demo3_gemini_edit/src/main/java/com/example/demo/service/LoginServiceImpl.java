package com.example.demo.service;

import org.springframework.stereotype.Service;

import com.example.demo.entity.Account;
import com.example.demo.entity.Login;
import com.example.demo.entity.LoginResult;
import com.example.demo.repository.LoginRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class LoginServiceImpl implements LoginService {
	
    private final LoginRepository loginRepository;

	@Override
	public LoginResult checkLogin(Login login) {
		
		LoginResult lr = new LoginResult();
		
		// LoginRepository に Login オブジェクトをそのまま渡し、平文パスワードでデータベースを検索
		Account account = loginRepository.findByLogin(login);
		
		// アカウントが存在すればアクティブを設定し、権限を取得
		if(account != null) {
			lr.setActive(true);
			lr.setAuthority(account.getAuthority());
			lr.setAccount(account); // 取得したAccountオブジェクトをLoginResultにセット
		}
		else {
			lr.setActive(false);
		}
		
		return lr;
	}
}