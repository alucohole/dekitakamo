package com.example.demo.repository;

import java.util.List;

import com.example.demo.entity.Status;

public interface StatusRepository {
    List<Status> findAll(); 
    Status findById(Integer statusId); 
}