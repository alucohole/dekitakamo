package com.example.demo.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Attendance;

import lombok.RequiredArgsConstructor;

@Repository
@RequiredArgsConstructor
public class AttendanceRepositoryImpl implements AttendanceRepository {

    private final JdbcTemplate jdbcTemplate;

    // AttendanceオブジェクトをマッピングするためのRowMapper
    private RowMapper<Attendance> attendanceRowMapper() {
        return new RowMapper<Attendance>() {
            @Override
            public Attendance mapRow(ResultSet rs, int rowNum) throws SQLException {
                Attendance attendance = new Attendance();
                attendance.setRegistId(rs.getInt("REGIST_ID"));
                attendance.setEmployeeId(rs.getString("EMPLOYEE_ID"));
                attendance.setStatusId(rs.getInt("STATUS_ID"));
                attendance.setWorkDate(rs.getObject("WORK_DATE", LocalDate.class));
                attendance.setStartTime(rs.getObject("START_TIME", LocalTime.class));
                attendance.setEndTime(rs.getObject("END_TIME", LocalTime.class));
                attendance.setBreakTime(rs.getInt("BREAK_TIME"));
                attendance.setComments(rs.getString("COMMENTS"));
                return attendance;
            }
        };
    }

    @Override
    public void add(Attendance attendance) {
        String sql = "INSERT INTO attendance_info (EMPLOYEE_ID, STATUS_ID, WORK_DATE, START_TIME, END_TIME, BREAK_TIME, COMMENTS) VALUES (?, ?, ?, ?, ?, ?, ?)";
        jdbcTemplate.update(sql,
                attendance.getEmployeeId(),
                attendance.getStatusId(),
                attendance.getWorkDate(),
                attendance.getStartTime(),
                attendance.getEndTime(),
                attendance.getBreakTime(),
                attendance.getComments());
    }

    @Override
    public List<Attendance> findByEmployeeIdAndWorkDateBetween(String employeeId, LocalDate startDate, LocalDate endDate) {
        String sql = "SELECT REGIST_ID, EMPLOYEE_ID, STATUS_ID, WORK_DATE, START_TIME, END_TIME, BREAK_TIME, COMMENTS FROM attendance_info WHERE EMPLOYEE_ID = ? AND WORK_DATE BETWEEN ? AND ? ORDER BY WORK_DATE ASC";
        return jdbcTemplate.query(sql, attendanceRowMapper(), employeeId, startDate, endDate);
    }

    @Override
    public void update(Attendance attendance) {
        String sql = "UPDATE attendance_info SET EMPLOYEE_ID = ?, STATUS_ID = ?, WORK_DATE = ?, START_TIME = ?, END_TIME = ?, BREAK_TIME = ?, COMMENTS = ? WHERE REGIST_ID = ?";
        jdbcTemplate.update(sql,
                attendance.getEmployeeId(),
                attendance.getStatusId(),
                attendance.getWorkDate(),
                attendance.getStartTime(),
                attendance.getEndTime(),
                attendance.getBreakTime(),
                attendance.getComments(),
                attendance.getRegistId());
    }

    @Override
    public Attendance findById(Integer registId) { // ★このメソッドを追加★
        String sql = "SELECT REGIST_ID, EMPLOYEE_ID, STATUS_ID, WORK_DATE, START_TIME, END_TIME, BREAK_TIME, COMMENTS FROM attendance_info WHERE REGIST_ID = ?";
        try {
            return jdbcTemplate.queryForObject(sql, attendanceRowMapper(), registId);
        } catch (EmptyResultDataAccessException e) {
            return null; // 該当するレコードがない場合はnullを返す
        }
    }
}