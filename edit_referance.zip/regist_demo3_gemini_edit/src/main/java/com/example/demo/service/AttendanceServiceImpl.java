package com.example.demo.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.entity.Attendance;
import com.example.demo.entity.Status;
import com.example.demo.exception.BusinessException;
import com.example.demo.repository.AttendanceRepository;
import com.example.demo.repository.DayoffRepository;
import com.example.demo.repository.StatusRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AttendanceServiceImpl implements AttendanceService {

    private final AttendanceRepository attendanceRepository;
    private final StatusRepository statusRepository;
    private final DayoffRepository dayoffRepository;

    @Override
    @Transactional
    public void regist(Attendance attendance) throws BusinessException {
        // ... (省略) ...
        // 4. 勤怠情報の登録
        attendanceRepository.add(attendance);
    }

    @Override
    public String getStatusNameById(Integer statusId) {
        Status status = statusRepository.findById(statusId);
        return (status != null) ? status.getStatusName() : "不明";
    }

    @Override
    public List<Status> getAllStatuses() {
        return statusRepository.findAll();
    }

    @Override
    public List<Attendance> searchAttendances(String employeeId, LocalDate startDate, LocalDate endDate) {
        return attendanceRepository.findByEmployeeIdAndWorkDateBetween(employeeId, startDate, endDate);
    }

    @Override
    @Transactional
    public void updateAttendance(Attendance updatedAttendance) throws BusinessException {
        // ... (省略) ...
    }

    @Override
    public Attendance findAttendanceById(Integer registId) { // ★このメソッドを追加★
        return attendanceRepository.findById(registId);
    }
}