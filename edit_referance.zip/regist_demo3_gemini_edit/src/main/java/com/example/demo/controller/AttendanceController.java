package com.example.demo.controller;

import java.time.LocalDate;
import java.util.List;

import jakarta.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.demo.entity.Attendance;
import com.example.demo.exception.BusinessException;
import com.example.demo.form.AttendanceForm;
import com.example.demo.form.AttendanceSearchForm;
import com.example.demo.service.AttendanceService;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
public class AttendanceController {
	
	private final AttendanceService service;

	// 勤怠登録フォーム表示 (GET)
	@GetMapping("/stamp_regist")
	public String showRegistFormGet(@RequestParam(required = false) String id, Model model, HttpSession session) {
	    AttendanceForm form = (AttendanceForm) model.asMap().get("attendanceForm");
	    if (form == null) {
	        form = new AttendanceForm();
	    }
	    
	    String loggedInEmployeeId = (String) session.getAttribute("loggedInEmployeeId"); // ★String型として取得★

	    if (id != null && !id.isEmpty()) {
	        form.setEmployeeId(id); // ★String型として設定★
	    } else if (loggedInEmployeeId != null) {
            form.setEmployeeId(loggedInEmployeeId);
        }
	    
	    if (form.getWorkDate() == null) {
	        form.setWorkDate(java.time.LocalDate.now()); 
	    }
	    
	    model.addAttribute("attendanceForm", form);
        model.addAttribute("employeeId", loggedInEmployeeId); // 画面表示用
        model.addAttribute("employeeName", session.getAttribute("loggedInEmployeeName")); // 画面表示用
	    return "stamp_regist";
	}

    // 勤怠登録フォーム表示 (POST)
    @PostMapping("/stamp_regist")
    public String showRegistFormPost(@RequestParam(required = false) String id, Model model, HttpSession session) {
        return showRegistFormGet(id, model, session);
    }

	@PostMapping("/confirm_regist")
	public String submitAttendance(@Validated @ModelAttribute AttendanceForm form,
			Model model,
			BindingResult result,
			HttpSession session,
			RedirectAttributes redirectAttributes) {
		
		if (result.hasErrors()) {
			model.addAttribute("attendanceForm", form);
			if (form.getStatusId() != null) {
			    String statusName = service.getStatusNameById(form.getStatusId()); 
			    model.addAttribute("statusName", statusName);
			}
            model.addAttribute("employeeId", session.getAttribute("loggedInEmployeeId"));
            model.addAttribute("employeeName", session.getAttribute("loggedInEmployeeName"));
			return "stamp_regist";
		}

		String statusName = service.getStatusNameById(form.getStatusId());
		model.addAttribute("statusName", statusName);

		return "confirm_regist";
	}

	@PostMapping("/complete")
	public String registAttendance(@Validated @ModelAttribute AttendanceForm form,
			Model model,
			BindingResult result,
			RedirectAttributes redirectAttributes) {
		
		if (result.hasErrors()) {
			redirectAttributes.addFlashAttribute("errorMessage", "フォームの入力内容にエラーがあります。");
			redirectAttributes.addFlashAttribute("attendanceForm", form);
			return "redirect:/stamp_regist"; 
		}

		try {
			Attendance at = new Attendance();
			at.setEmployeeId(form.getEmployeeId()); // formのString型employeeIdを使用
			at.setStatusId(form.getStatusId());
			at.setWorkDate(form.getWorkDate());
			at.setStartTime(form.getStartTime());
			at.setEndTime(form.getEndTime());
			at.setBreakTime(form.getBreakTime());
			at.setComments(form.getComments());
			
			service.regist(at);
			
			redirectAttributes.addFlashAttribute("msg", "勤怠登録");

		} catch (BusinessException e) {
			redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
			redirectAttributes.addFlashAttribute("attendanceForm", form);
			return "redirect:/stamp_regist"; 
		} catch (Exception e) {
		    redirectAttributes.addFlashAttribute("errorMessage", "予期せぬエラーが発生しました: " + e.getMessage());
		    redirectAttributes.addFlashAttribute("attendanceForm", form);
		    return "redirect:/stamp_regist";
		}

		return "redirect:/complete";
	}
	
	@GetMapping("/complete")
	public String showComplete(Model model) {
	    return "complete";
	}

	@GetMapping("/top")
	public String returnTopGet(Model model) {
		return "top";
	}

	@PostMapping("/top_from_register")
	public String returnTopPost(@RequestParam(required = false) String id,
			Model model,
			@ModelAttribute AttendanceForm form) {
		return "redirect:/top";
	}

    // 勤怠編集検索画面の表示
    @GetMapping("/attendance_edit_search")
    public String showAttendanceEditSearch(Model model, HttpSession session) {
        AttendanceSearchForm searchForm = new AttendanceSearchForm();
        String loggedInEmployeeId = (String) session.getAttribute("loggedInEmployeeId"); // ★String型として取得★
        
        searchForm.setEmployeeId(loggedInEmployeeId); // ログイン中の社員IDをフォームに自動設定

        LocalDate today = LocalDate.now();
        searchForm.setSearchStartDate(today.withDayOfMonth(1));
        searchForm.setSearchEndDate(today);

        model.addAttribute("searchForm", searchForm);
        model.addAttribute("employeeId", loggedInEmployeeId);
        model.addAttribute("employeeName", session.getAttribute("loggedInEmployeeName"));
        return "attendance_edit_search";
    }

    // 勤怠情報検索結果の表示
    @PostMapping("/attendance_search_results")
    public String searchAttendance(@ModelAttribute AttendanceSearchForm searchForm, Model model, HttpSession session) {
        String loggedInEmployeeId = (String) session.getAttribute("loggedInEmployeeId"); // ★String型として取得★
        searchForm.setEmployeeId(loggedInEmployeeId); // 念のため、セッションのIDで上書き

        if (searchForm.getSearchStartDate() == null || searchForm.getSearchEndDate() == null) {
            model.addAttribute("errorMessage", "検索開始日と終了日を必ず入力してください。");
            model.addAttribute("searchForm", searchForm);
            model.addAttribute("employeeId", loggedInEmployeeId);
            model.addAttribute("employeeName", session.getAttribute("loggedInEmployeeName"));
            return "attendance_edit_search";
        }

        List<Attendance> searchResults = service.searchAttendances(
            searchForm.getEmployeeId(), 
            searchForm.getSearchStartDate(), 
            searchForm.getSearchEndDate()
        );
        
        model.addAttribute("searchResults", searchResults);
        model.addAttribute("searchForm", searchForm);
        model.addAttribute("employeeId", loggedInEmployeeId);
        model.addAttribute("employeeName", session.getAttribute("loggedInEmployeeName"));
        
        return "attendance_search_results";
    }

    // 勤怠情報編集画面の表示 (GETリクエスト)
    @GetMapping("/attendance_edit")
    public String showAttendanceEdit(@RequestParam("registId") Integer registId, Model model, HttpSession session) {
        Attendance attendanceToEdit = service.findAttendanceById(registId);
        
        if (attendanceToEdit == null) {
            model.addAttribute("errorMessage", "編集対象の勤怠情報が見つかりませんでした。");
            return "redirect:/attendance_edit_search";
        }

        String loggedInEmployeeId = (String) session.getAttribute("loggedInEmployeeId"); // ★String型として取得★
        if (loggedInEmployeeId == null || !loggedInEmployeeId.equals(attendanceToEdit.getEmployeeId())) {
            model.addAttribute("errorMessage", "他の社員の勤怠情報は編集できません。");
            return "redirect:/attendance_edit_search";
        }

        AttendanceForm editForm = new AttendanceForm();
        editForm.setRegistId(attendanceToEdit.getRegistId());
        editForm.setEmployeeId(attendanceToEdit.getEmployeeId()); // ★String型として設定★
        editForm.setWorkDate(attendanceToEdit.getWorkDate());
        editForm.setStatusId(attendanceToEdit.getStatusId());
        editForm.setStartTime(attendanceToEdit.getStartTime());
        editForm.setEndTime(attendanceToEdit.getEndTime());
        editForm.setBreakTime(attendanceToEdit.getBreakTime());
        editForm.setComments(attendanceToEdit.getComments());

        model.addAttribute("editForm", editForm);
        model.addAttribute("statusName", service.getStatusNameById(attendanceToEdit.getStatusId()));
        model.addAttribute("employeeId", loggedInEmployeeId);
        model.addAttribute("employeeName", session.getAttribute("loggedInEmployeeName"));
        
        return "attendance_edit";
    }

    // 勤怠情報更新処理 (POSTリクエスト)
    @PostMapping("/attendance_update")
    public String updateAttendance(@Validated @ModelAttribute("editForm") AttendanceForm form,
                                  BindingResult result,
                                  Model model,
                                  RedirectAttributes redirectAttributes,
                                  HttpSession session) {

        String loggedInEmployeeId = (String) session.getAttribute("loggedInEmployeeId"); // ★String型として取得★

        if (loggedInEmployeeId == null || !loggedInEmployeeId.equals(form.getEmployeeId())) {
             redirectAttributes.addFlashAttribute("errorMessage", "不正な操作です。");
             return "redirect:/attendance_edit_search";
        }

        if (result.hasErrors()) {
            model.addAttribute("errorMessage", "入力内容にエラーがあります。");
            model.addAttribute("editForm", form);
            model.addAttribute("statusName", service.getStatusNameById(form.getStatusId()));
            model.addAttribute("employeeId", loggedInEmployeeId);
            model.addAttribute("employeeName", session.getAttribute("loggedInEmployeeName"));
            return "attendance_edit";
        }

        try {
            Attendance attendanceToUpdate = new Attendance();
            attendanceToUpdate.setRegistId(form.getRegistId());
            attendanceToUpdate.setEmployeeId(form.getEmployeeId()); // ★String型として設定★
            attendanceToUpdate.setWorkDate(form.getWorkDate());
            attendanceToUpdate.setStatusId(form.getStatusId());
            attendanceToUpdate.setStartTime(form.getStartTime());
            attendanceToUpdate.setEndTime(form.getEndTime());
            attendanceToUpdate.setBreakTime(form.getBreakTime());
            attendanceToUpdate.setComments(form.getComments());

            service.updateAttendance(attendanceToUpdate);

            redirectAttributes.addFlashAttribute("msg", "勤怠情報を更新しました。");
            return "redirect:/attendance_edit_search";
            
        } catch (BusinessException e) {
            model.addAttribute("errorMessage", e.getMessage());
            model.addAttribute("editForm", form);
            model.addAttribute("statusName", service.getStatusNameById(form.getStatusId()));
            model.addAttribute("employeeId", loggedInEmployeeId);
            model.addAttribute("employeeName", session.getAttribute("loggedInEmployeeName"));
            return "attendance_edit";
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("errorMessage", "予期せぬエラーが発生しました。");
            model.addAttribute("editForm", form);
            model.addAttribute("statusName", service.getStatusNameById(form.getStatusId()));
            model.addAttribute("employeeId", loggedInEmployeeId);
            model.addAttribute("employeeName", session.getAttribute("loggedInEmployeeName"));
            return "attendance_edit";
        }
    }
}