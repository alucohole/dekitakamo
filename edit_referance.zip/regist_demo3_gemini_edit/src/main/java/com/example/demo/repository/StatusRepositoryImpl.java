package com.example.demo.repository;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Status;

import lombok.RequiredArgsConstructor;

@Repository
@RequiredArgsConstructor
public class StatusRepositoryImpl implements StatusRepository {

    private final JdbcTemplate jdbcTemplate;

    // StatusオブジェクトをマッピングするためのRowMapper
    private RowMapper<Status> statusRowMapper() {
        return (rs, rowNum) -> {
            Status status = new Status();
            status.setStatusId(rs.getInt("STATUS_ID"));
            status.setStatusName(rs.getString("STATUS_NAME"));
            return status;
        };
    }

    @Override
    public List<Status> findAll() {
        String sql = "SELECT STATUS_ID, STATUS_NAME FROM STATUS ORDER BY STATUS_ID ASC";
        return jdbcTemplate.query(sql, statusRowMapper());
    }

    @Override
    public Status findById(Integer statusId) {
        String sql = "SELECT STATUS_ID, STATUS_NAME FROM STATUS WHERE STATUS_ID = ?";
        try {
            return jdbcTemplate.queryForObject(sql, statusRowMapper(), statusId);
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }
}