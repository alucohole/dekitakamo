package com.example.demo.form;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import lombok.Data;

@Data
public class LoginForm {

    @NotBlank(message = "社員IDは必須です")
    @Size(min=6, max = 6, message = "社員IDは6桁で入力してください") 
    private String employeeId; 

    @NotBlank(message = "パスワードは必須です")
    @Size(min = 4, max = 64, message = "パスワードは4文字以上64文字以下で入力してください")
    private String password;
}