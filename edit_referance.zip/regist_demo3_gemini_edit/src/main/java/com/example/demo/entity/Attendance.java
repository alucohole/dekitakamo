package com.example.demo.entity;

// import java.sql.Date; // これを削除
import java.time.LocalDate; // ★これを追加★
import java.time.LocalTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Attendance {
    private Integer registId;
    private String employeeId;
    private Integer statusId;
    private LocalDate workDate; // ★型を LocalDate に変更★
    private LocalTime startTime;
    private LocalTime endTime;
    private Integer breakTime;
    private String comments;
}