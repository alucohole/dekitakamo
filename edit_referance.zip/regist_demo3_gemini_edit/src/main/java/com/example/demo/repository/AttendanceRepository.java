package com.example.demo.repository;

import java.time.LocalDate;
import java.util.List;

import com.example.demo.entity.Attendance;

public interface AttendanceRepository {
    void add(Attendance attendance);
    List<Attendance> findByEmployeeIdAndWorkDateBetween(String employeeId, LocalDate startDate, LocalDate endDate);
    void update(Attendance attendance);
    Attendance findById(Integer registId); // ★この行を追加★
}