package com.example.demo.repository;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper; // RowMapperをインポート
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Dayoff;

import lombok.RequiredArgsConstructor;

@Repository
@RequiredArgsConstructor
public class DayoffRepositoryImpl implements DayoffRepository {

    private final JdbcTemplate jdbcTemplate;

    @Override
    public Dayoff findByEmployeeId(String employeeId) { // ★String型に修正★
        String sql = "SELECT EMPLOYEE_ID, YU_HOLIDAY, FURI_HOLIDAY FROM DAYOFF WHERE EMPLOYEE_ID = ?";
        try {
            return jdbcTemplate.queryForObject(sql, dayoffRowMapper(), employeeId);
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }

    @Override
    public void updateFuriHoliday(String employeeId, int change) { // ★String型に修正★
        String sql = "UPDATE DAYOFF SET FURI_HOLIDAY = FURI_HOLIDAY + ? WHERE EMPLOYEE_ID = ?";
        jdbcTemplate.update(sql, change, employeeId);
    }

    @Override
    public void updateYuHoliday(String employeeId, int change) { // ★String型に修正★
        String sql = "UPDATE DAYOFF SET YU_HOLIDAY = YU_HOLIDAY + ? WHERE EMPLOYEE_ID = ?";
        jdbcTemplate.update(sql, change, employeeId);
    }

    @Override
    public void insertInitialDayoff(String employeeId) { // ★String型に修正★
        String sql = "INSERT INTO DAYOFF (EMPLOYEE_ID, YU_HOLIDAY, FURI_HOLIDAY) VALUES (?, ?, ?)";
        jdbcTemplate.update(sql, employeeId, 0, 0); // 初期値として0を設定
    }

    @Override
    public Integer findFuriHolidayByEmployeeId(String employeeId) { // ★String型に修正★
        String sql = "SELECT FURI_HOLIDAY FROM DAYOFF WHERE EMPLOYEE_ID = ?";
        try {
            return jdbcTemplate.queryForObject(sql, Integer.class, employeeId);
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }

    // RowMapperをヘルパーメソッドとして定義
    private RowMapper<Dayoff> dayoffRowMapper() {
        return (rs, rowNum) -> {
            Dayoff dayoff = new Dayoff();
            dayoff.setEmployeeId(rs.getString("EMPLOYEE_ID")); // ★String型として取得★
            dayoff.setYuHoliday(rs.getInt("YU_HOLIDAY"));
            dayoff.setFuriHoliday(rs.getInt("FURI_HOLIDAY"));
            return dayoff;
        };
    }
}